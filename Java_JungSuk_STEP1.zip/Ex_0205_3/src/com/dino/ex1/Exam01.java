package com.dino.ex1;

public class Exam01 {
	public static void main(String[] args) {
		int a = 4;
		float b = 3;
		
		int c = (int)(++a + -b);  
		System.out.println(c);
	}
}
