package com.dino.ex1;

public class Exam03 {
	public static void main(String[] args) {

		int a = 5, b = 4;
		float c;
		double d;
		System.out.println(c = a % b);
		System.out.println(d = a % b);

	}
}
