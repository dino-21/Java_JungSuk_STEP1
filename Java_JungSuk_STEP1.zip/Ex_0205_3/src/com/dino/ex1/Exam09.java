package com.dino.ex1;

public class Exam09 {
	public static void main(String[] args) {

		int x = 1;
		int y = 2;

		int z = ++x + -y;
		System.out.println("출력 결과 : " + z);
	}
}
